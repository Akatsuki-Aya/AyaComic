"use strict";

function isNULL(t){

    if($.isArray(t)){

        if(t.length==0){
            return true;
        }else{
            return false;
        }

    }else{

        if(t==''||t==undefined||t==null){
            return true;
        }else{
            return false;
        }
    }
}

function removeScript(text){
    var SCRIPT_REGEX = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;
    while (SCRIPT_REGEX.test(text)) {
        text = text.replace(SCRIPT_REGEX, "");
    }
    return text;
}

function sleep(millis){
    var date = new Date();
    var curDate = null;
    do { curDate = new Date(); }
    while(curDate-date < millis);
}

function getContentType(type) {
    
    var tlist= ['application/json','text/plain','text/html','text/xml','application/javascript'];
    for(var i=0;i<tlist.length;i++){
        var t = tlist[i];
        if(type.contains(t)==true){
            return t;
        }
    }
    return '';
}

function isPostType(method) {
    
    method = method.toUpperCase();
    var PostMethods=['POST','PUT','PATCH','DELETE','OPTIONS','LINK','UNLINK','LOCK','PROPFIND','VIEW'];
    var GetMethods=['GET','COPY','HEAD','PURGE','UNLOCK'];
    if($.inArray(method, PostMethods )!=-1){
        return true;
    }else{
        return false;
    }
}

var DomUtils ={
    findDom:function(tabID,name){
        return $('[tab-id="'+tabID+'"][name="'+name+'"]');
    }
};

function dataURLtoBlob(e){
    for (var r = e.split(","), a = r[0].match(/:(.*?);/)[1], t = atob(r[1]), o = t.length, s = new Uint8Array(o); o--;) s[o] = t.charCodeAt(o);
    return new Blob([s], {
        type: a
    })
}